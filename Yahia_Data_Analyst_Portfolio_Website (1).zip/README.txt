# Yahia Mazloum Portfolio Website

This is a one-page portfolio website for a Junior Data Analyst.

Before publishing, replace:
your-email@example.com

with your actual professional email address.

The site is static HTML/CSS and can be published on GitHub Pages, Netlify, or another static hosting service.
